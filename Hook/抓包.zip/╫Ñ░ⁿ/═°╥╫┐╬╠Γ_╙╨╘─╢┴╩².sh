POST /mp/getappmsgext?f=json&mock=&uin=777&key=777&pass_ticket=%25252F7RYPJTfQlIcDFQhF133s%25252BvdDlX7E9NQ8n7nu6aQfwyxsQZxKhOk9Efc9yAxutaf&wxtoken=777&devicetype=android-23&clientversion=26060532&appmsg_token=960_E2CLxkLQJSEgUfHjPVSwcYIAVfsAGTwY8Y-HQkI__Bsdzzba99JsRymS2bMaDxw46Z54o14Q-iiywgNm&x5=1&f=json HTTP/1.1
accept: */*
connection: Keep-Alive
user-agent: Mozilla/5.0 (Linux; Android 7.1.2; Pixel XL Build/NZH54D; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.132 MQQBrowser/6.2 TBS/043909 Mobile Safari/537.36 MicroMessenger/6.6.3.1260(0x26060336) NetType/WIFI Language/zh_CN
Cookie: rewardsn=; wxtokenkey=777; wxuin=3789529722; devicetype=android-23; version=26060532; lang=zh_CN; pass_ticket=HMZ8TBKS8oeX8Pj+dhnOxbso8oWFqy4hu59VUmrB+w57xWVcBrMdzl5QrIej+zwJ; wap_sid2=CPrE/o4OElxIZnJiWWI5dzM4MFYyQmxlMmg4dGNDWGhYeE1wZDEweUc2d0YxWUtRWmhBWXZpOTNyQ0NkYk9TTWZxajRKNTVmTHp5Q0dRbUM2Nm03OC05NUtvNDI5Y0FEQUFBfjCukP/YBTgNQAE=
Q-UA2: QV=3&PL=ADR&PR=WX&PP=com.tencent.mm&PPVN=6.6.5&TBSVC=43603&CO=BK&COVC=043909&PB=GE&VE=GA&DE=PHONE&CHID=0&LCID=9422&MO= PixelXL &RL=1440*2392&OS=7.1.2&API=25
Q-GUID: b08a5edb5e2a655000ca6e7e13b788cb
Q-Auth: 31045b957cf33acf31e40be2f3e71c5217597676a9729f1b
X-Requested-With: XMLHttpRequest
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
Accept-Language: zh-CN,en-US;q=0.8
Host: mp.weixin.qq.com
Accept-Encoding: gzip
Content-Length: 477


{"advertisement_num":0,"advertisement_info":[],"appmsgstat":{"show":true,"is_login":true,"liked":false,"read_num":5642,"like_num":24,"ret":0,"real_read_num":0},"reward_head_imgs":[],"base_resp":{"wxtoken":777}}

{"advertisement_num":0,"advertisement_info":[],"appmsgstat":{"show":true,"is_login":true,"liked":false,"read_num":5642,"like_num":24,"ret":0,"real_read_num":0},"comment_enabled":1,"reward_head_imgs":[],"only_fans_can_comment":false,"comment_count":9,"is_fans":0,"nick_name":"测试机器人","logo_url":"http:\/\/wx.qlogo.cn\/mmopen\/CB62DhMPeGdz3iavnXic6Y1ib8AOrlgx6oq7Ig28m5asc7urHiaXl71hncIsfA53mxzeLe9kZKnv9ovGrTibicWpSFjnefosCslTOg\/132","friend_comment_enabled":1,"base_resp":{"wxtoken":777}}


#	结果	协议	主机	URL	主体	缓存	内容类型	进程	注释	自定义	
1	204	HTTP	pms.mb.qq.com	/rsp204	0		text/vnd.wap.wml; charset=utf-8				
2	200	HTTP	log.tbs.qq.com	/ajax?c=dl&v=2&k=01c9b07ebf9c0d4ce99ecf54a8088198a7c9a716b2ff605f01ae47af697dfa3bdbfc026d908cba22d898cb48bac9482fbf15c1a062cc004820eb8ec7d95c9166becb04df30e7a31522918947f60144bcecb31480fab3a2c7d1bf7d21af7114933ce023d40a5f832f76d384a2fe0ac8fdd7719ccffbc9c35b779b5491235262e8	7		text/html; charset=utf-8				
3	200	HTTP	Tunnel to	mp.weixin.qq.com:443	0						
4	200	HTTPS	mp.weixin.qq.com	/s?__biz=MjM5MDA1Njk4MA==&mid=2650363071&idx=3&sn=66e28ab81023594c42b0dc3f019e610e&ascene=1&devicetype=android-23&version=26060532&nettype=WIFI&abtest_cookie=AwABAAoACwAMAAkAPoseAOOLHgBIkh4A8JIeAG%2BTHgCdkx4AuZMeAPKTHgD9kx4AAAA%3D&lang=zh_CN&pass_ticket=%2F7RYPJTfQlIcDFQhF133s%2BvdDlX7E9NQ8n7nu6aQfwyxsQZxKhOk9Efc9yAxutaf&wx_header=1	35,151	public, max-age=500; Expires: Tue, 12 Jun 2018 21:29:07 +0800	text/html; charset=UTF-8				
5	200	HTTP	oth.eve.mdt.qq.com:8080	/analytics/upload?rid=5b0406c4b002b575&sid=1c6e7c0c27633cc4572fa8c8e1218c34	128						
6	200	HTTP	oth.eve.mdt.qq.com:8080	/analytics/upload?rid=6c0d893ff7289023&sid=1c6e7c0c27633cc4572fa8c8e1218c34	128						
7	200	HTTP	Tunnel to	mp.weixin.qq.com:443	0						
8	200	HTTPS	mp.weixin.qq.com	/mp/getappmsgext?f=json&mock=&uin=777&key=777&pass_ticket=%25252F7RYPJTfQlIcDFQhF133s%25252BvdDlX7E9NQ8n7nu6aQfwyxsQZxKhOk9Efc9yAxutaf&wxtoken=777&devicetype=android-23&clientversion=26060532&appmsg_token=960_E2CLxkLQJSEgUfHjPVSwcYIAVfsAGTwY8Y-HQkI__Bsdzzba99JsRymS2bMaDxw46Z54o14Q-iiywgNm&x5=1&f=json	157	no-cache, must-revalidate	application/json; charset=UTF-8				
9	200	HTTPS	mp.weixin.qq.com	/mp/jsreport?1=1&key=2&content=biz:MjM5MDA1Njk4MA==,mid:2650363071,uin:777[key2]ajax_err&r=0.059417169317609986	0						
10	200	HTTP	Tunnel to	servicewechat.com:443	0						
11	200	HTTPS	mp.weixin.qq.com	/mp/appmsgpicreport?__biz=MjM5MDA1Njk4MA==&uin=777&key=777&pass_ticket=%25252F7RYPJTfQlIcDFQhF133s%25252BvdDlX7E9NQ8n7nu6aQfwyxsQZxKhOk9Efc9yAxutaf&wxtoken=777&devicetype=android-23&clientversion=26060532&appmsg_token=960_E2CLxkLQJSEgUfHjPVSwcYIAVfsAGTwY8Y-HQkI__Bsdzzba99JsRymS2bMaDxw46Z54o14Q-iiywgNm&x5=1&f=json	11	no-cache, must-revalidate	application/json; charset=UTF-8				
12	200	HTTP	Tunnel to	mp.weixin.qq.com:443	0						
13	200	HTTPS	mp.weixin.qq.com	/mp/jsmonitor?idkey=27822_1_3542;27822_0_1;27822_3_2452;27822_2_1;27822_5_2447;27822_4_1;27822_7_3542;27822_6_1;27822_71_3542;27822_70_1;27822_75_3542;27822_74_1;27822_65_224;27822_64_1;27822_67_201;27822_66_1&t=0.3772999242240369	40	no-cache, must-revalidate	application/json; charset=UTF-8				
14	200	HTTP	log.tbs.qq.com	/ajax?c=pu&v=2&k=49e75f992a82c9c6ee3a525b668c5881698e4a4cb1add359184ed55227584660fa84e9398dc9d61d88465e6c75af31d721224b30e2d572241ce655d6679a4e72b874272748a9af0f2324e24dd4518a5911de97e8cccbb49e18d1a35a91ecd4e23218027b2405193709548e3ab204627b35334e47b43c0448072dfd09ef90e84d	7		text/html; charset=utf-8				
15	200	HTTPS	mp.weixin.qq.com	/mp/appmsgreport?action=page_time&uin=777&key=777&pass_ticket=%25252F7RYPJTfQlIcDFQhF133s%25252BvdDlX7E9NQ8n7nu6aQfwyxsQZxKhOk9Efc9yAxutaf&wxtoken=777&devicetype=android-23&clientversion=26060532&appmsg_token=960_E2CLxkLQJSEgUfHjPVSwcYIAVfsAGTwY8Y-HQkI__Bsdzzba99JsRymS2bMaDxw46Z54o14Q-iiywgNm&x5=1&f=json	0	no-cache, must-revalidate					
17	200	HTTP	101.91.63.221:8080	/?tk=f9448bb73ff97840838f0f4012c612b4d84c5b32d528855b5d55372f39eccb53323f6e7f03b881db21133b1bf2ae5bc5&iv=6005dcb9634b823d&encrypt=17	112	no-cache	application/multipart-formdata				
18	200	HTTP	wifi.360.cn	/conf/pub.html?t=1405293125&pid=freeap_school&mid=fe2245502c94f8ba9987fc0dac751f78&version=5304070&os=10&rand=28	143		text/html	360ap:2080			
