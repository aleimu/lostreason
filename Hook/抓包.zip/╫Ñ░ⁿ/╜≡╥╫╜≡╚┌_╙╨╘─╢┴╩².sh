POST /mp/getappmsgext?f=json&mock=&uin=777&key=777&pass_ticket=%25252F7RYPJTfQlIcDFQhF133s%25252BvdDlX7E9NQ8n7nu6aQfwyxsQZxKhOk9Efc9yAxutaf&wxtoken=777&devicetype=android-23&clientversion=26060532&appmsg_token=960_PJIWnY9xY8IW1xjaOYOaVPOXmAaThnR8GCpy9RbtCfql_TymndQsaEJYmD61GRScbUPD2i6Hd8_iGy8t&x5=1&f=json HTTP/1.1
accept: */*
connection: Keep-Alive
user-agent: Mozilla/5.0 (Linux; Android 7.1.2; Pixel XL Build/NZH54D; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.132 MQQBrowser/6.2 TBS/043909 Mobile Safari/537.36 MicroMessenger/6.6.3.1260(0x26060336) NetType/WIFI Language/zh_CN
Cookie: rewardsn=; wxtokenkey=777; wxuin=3789529722; devicetype=android-23; version=26060532; lang=zh_CN; pass_ticket=HMZ8TBKS8oeX8Pj+dhnOxbso8oWFqy4hu59VUmrB+w57xWVcBrMdzl5QrIej+zwJ; wap_sid2=CPrE/o4OElxIZnJiWWI5dzM4MFYyQmxlMmg4dGNDWGhYeE1wZDEweUc2d0YxWUtRWmhBWXZpOTNyQ0NkYk9TTWZxajRKNTVmTHp5Q0dRbUM2Nm03OC05NUtvNDI5Y0FEQUFBfjCukP/YBTgNQAE=
Q-UA2: QV=3&PL=ADR&PR=WX&PP=com.tencent.mm&PPVN=6.6.5&TBSVC=43603&CO=BK&COVC=043909&PB=GE&VE=GA&DE=PHONE&CHID=0&LCID=9422&MO= PixelXL &RL=1440*2392&OS=7.1.2&API=25
Q-GUID: b08a5edb5e2a655000ca6e7e13b788cb
Q-Auth: 31045b957cf33acf31e40be2f3e71c5217597676a9729f1b
X-Requested-With: XMLHttpRequest
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
Accept-Language: zh-CN,en-US;q=0.8
Host: mp.weixin.qq.com
Accept-Encoding: gzip
Content-Length: 568


#	结果	协议	主机	URL	主体	缓存	内容类型	进程	注释	自定义	
1	200	HTTPS	mp.weixin.qq.com	/s?__biz=MzI4NTM2MzY4Mg==&mid=2247485058&idx=1&sn=55f0b125d49bc62f9cdc464edad8c42b&chksm=ebec1a0fdc9b9319fe3ce05e23bf43927e411e6a198a1c9a2341621f10f7e83e04e6ccc0681c&scene=0&ascene=7&devicetype=android-23&version=26060532&nettype=WIFI&abtest_cookie=AwABAAoACwAMAAkAPoseAOOLHgBIkh4A8JIeAG%2BTHgCdkx4AuZMeAPKTHgD9kx4AAAA%3D&lang=zh_CN&pass_ticket=%2F7RYPJTfQlIcDFQhF133s%2BvdDlX7E9NQ8n7nu6aQfwyxsQZxKhOk9Efc9yAxutaf&wx_header=1	28,877	public, max-age=500; Expires: Tue, 12 Jun 2018 21:34:30 +0800	text/html; charset=UTF-8				
2	200	HTTPS	mp.weixin.qq.com	/mp/getappmsgext?f=json&mock=&uin=777&key=777&pass_ticket=%25252F7RYPJTfQlIcDFQhF133s%25252BvdDlX7E9NQ8n7nu6aQfwyxsQZxKhOk9Efc9yAxutaf&wxtoken=777&devicetype=android-23&clientversion=26060532&appmsg_token=960_PJIWnY9xY8IW1xjaOYOaVPOXmAaThnR8GCpy9RbtCfql_TymndQsaEJYmD61GRScbUPD2i6Hd8_iGy8t&x5=1&f=json	153	no-cache, must-revalidate	application/json; charset=UTF-8				
3	200	HTTPS	mp.weixin.qq.com	/mp/jsreport?1=1&key=2&content=biz:MzI4NTM2MzY4Mg==,mid:2247485058,uin:777[key2]ajax_err&r=0.39216837808886673	0						
4	200	HTTPS	mp.weixin.qq.com	/mp/appmsgpicreport?__biz=MzI4NTM2MzY4Mg==&uin=777&key=777&pass_ticket=%25252F7RYPJTfQlIcDFQhF133s%25252BvdDlX7E9NQ8n7nu6aQfwyxsQZxKhOk9Efc9yAxutaf&wxtoken=777&devicetype=android-23&clientversion=26060532&appmsg_token=960_PJIWnY9xY8IW1xjaOYOaVPOXmAaThnR8GCpy9RbtCfql_TymndQsaEJYmD61GRScbUPD2i6Hd8_iGy8t&x5=1&f=json	11	no-cache, must-revalidate	application/json; charset=UTF-8				
5	200	HTTP	log.tbs.qq.com	/ajax?c=pu&v=2&k=49e75f992a82c9c6ee3a525b668c5881698e4a4cb1add359184ed55227584660fa84e9398dc9d61d88465e6c75af31d721224b30e2d572241ce655d6679a4e72b874272748a9af0f2324e24dd4518a5911de97e8cccbb49e18d1a35a91ecd4e23218027b2405193709548e3ab204627b35334e47b43c0448072dfd09ef90e84d	7		text/html; charset=utf-8				
6	200	HTTPS	mp.weixin.qq.com	/mp/appmsgreport?action=page_time&uin=777&key=777&pass_ticket=%25252F7RYPJTfQlIcDFQhF133s%25252BvdDlX7E9NQ8n7nu6aQfwyxsQZxKhOk9Efc9yAxutaf&wxtoken=777&devicetype=android-23&clientversion=26060532&appmsg_token=960_PJIWnY9xY8IW1xjaOYOaVPOXmAaThnR8GCpy9RbtCfql_TymndQsaEJYmD61GRScbUPD2i6Hd8_iGy8t&x5=1&f=json	0	no-cache, must-revalidate					
