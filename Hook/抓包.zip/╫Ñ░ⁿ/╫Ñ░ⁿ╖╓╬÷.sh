POST /mp/getappmsgext?f=json&mock=&uin=777&key=777&pass_ticket=HMZ8TBKS8oeX8Pj%25252BdhnOxbso8oWFqy4hu59VUmrB%25252Bw57xWVcBrMdzl5QrIej%25252BzwJ&wxtoken=777&devicetype=android-23&clientversion=26060532&appmsg_token=960_4OP28QPXKpMHTraKNuGR_u__vM7wVJuVTZWqvkF15AwlRToPhFm_EOMgvaEYDNeYEOi8QqdRrGonLMe1&x5=1&f=json HTTP/1.1
accept: */*
connection: Keep-Alive
user-agent: Mozilla/5.0 (Linux; Android 7.1.2; Pixel XL Build/NZH54D; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.132 MQQBrowser/6.2 TBS/043909 Mobile Safari/537.36 MicroMessenger/6.6.3.1260(0x26060336) NetType/WIFI Language/zh_CN
Cookie: wxuin=3789529722; devicetype=android-23; version=26060532; lang=zh_CN; pass_ticket=/0CNwnlanWByDE+oz3ssxVMY75/FjuAe4bXG/nHvn5C+ZKEMZeXoEupWQe5viX0P; wap_sid2=CPrE/o4OEogBTzMtV2tmLXU2ZHdTV282RXpuQVhWcjA2TEVZSlVUdkF4U0hhRkxpdTV0aEJPOXYycVdsLUYzNk9mc0JXdFlXMDhxUmdGcjZaanRYelE4ZmN0eGltdE9za0RYQUkxbm9iTnZ3UHhsc09zZm1zUFZtbk05WTFvSlc1Vm4zQk5iNUJ3QU1BQUF+fjC1i/7YBTgNQAE=; rewardsn=; wxtokenkey=777
Q-UA2: QV=3&PL=ADR&PR=WX&PP=com.tencent.mm&PPVN=6.6.5&TBSVC=43603&CO=BK&COVC=043909&PB=GE&VE=GA&DE=PHONE&CHID=0&LCID=9422&MO= PixelXL &RL=1440*2392&OS=7.1.2&API=25
Q-GUID: b08a5edb5e2a655000ca6e7e13b788cb
Q-Auth: 31045b957cf33acf31e40be2f3e71c5217597676a9729f1b
X-Requested-With: XMLHttpRequest
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
Accept-Language: zh-CN,en-US;q=0.8
Host: mp.weixin.qq.com
Accept-Encoding: gzip
Content-Length: 570


{"advertisement_info":[],"reward_head_imgs":[]}


POST /mp/getappmsgext?f=json&mock=&uin=777&key=777&pass_ticket=HMZ8TBKS8oeX8Pj%25252BdhnOxbso8oWFqy4hu59VUmrB%25252Bw57xWVcBrMdzl5QrIej%25252BzwJ&wxtoken=777&devicetype=android-23&clientversion=26060532&appmsg_token=960_yaUMICsRvP%252FLLtT6OYOaVPOXmAaThnR8GCpy9ZeWNR5QOOQvIVQr9Lg4qpo7T9EIuhzWYGNvRkCGnrjS&x5=1&f=json HTTP/1.1
accept: */*
connection: Keep-Alive
user-agent: Mozilla/5.0 (Linux; Android 7.1.2; Pixel XL Build/NZH54D; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.132 MQQBrowser/6.2 TBS/043909 Mobile Safari/537.36 MicroMessenger/6.6.3.1260(0x26060336) NetType/WIFI Language/zh_CN
Cookie: wxuin=3789529722; devicetype=android-23; version=26060532; lang=zh_CN; pass_ticket=/0CNwnlanWByDE+oz3ssxVMY75/FjuAe4bXG/nHvn5C+ZKEMZeXoEupWQe5viX0P; wap_sid2=CPrE/o4OEogBTzMtV2tmLXU2ZHdTV282RXpuQVhWcjA2TEVZSlVUdkF4U0hhRkxpdTV0aEJPOXYycVdsLUYzNk9mc0JXdFlXMDhxUmdGcjZaanRYelE4ZmN0eGltdE9za0RYQUkxbm9iTnZ3UHhsc09zZm1zUFZtbk05WTFvSlc1Vm4zQk5iNUJ3QU1BQUF+fjC1i/7YBTgNQAE=; rewardsn=; wxtokenkey=777
Q-UA2: QV=3&PL=ADR&PR=WX&PP=com.tencent.mm&PPVN=6.6.5&TBSVC=43603&CO=BK&COVC=043909&PB=GE&VE=GA&DE=PHONE&CHID=0&LCID=9422&MO= PixelXL &RL=1440*2392&OS=7.1.2&API=25
Q-GUID: b08a5edb5e2a655000ca6e7e13b788cb
Q-Auth: 31045b957cf33acf31e40be2f3e71c5217597676a9729f1b
X-Requested-With: XMLHttpRequest
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
Accept-Language: zh-CN,en-US;q=0.8
Host: mp.weixin.qq.com
Accept-Encoding: gzip
Content-Length: 570


POST /mp/getappmsgext?f=json&mock=&uin=777&key=777&pass_ticket=HMZ8TBKS8oeX8Pj%25252BdhnOxbso8oWFqy4hu59VUmrB%25252Bw57xWVcBrMdzl5QrIej%25252BzwJ&wxtoken=777&devicetype=android-23&clientversion=26060532&appmsg_token=960_yaUMICsRvP%252FLLtT6OYOaVPOXmAaThnR8GCpy9ZeWNR5QOOQvIVQr9Lg4qpo7T9EIuhzWYGNvRkCGnrjS&x5=1&f=json HTTP/1.1
accept: */*
connection: Keep-Alive
user-agent: Mozilla/5.0 (Linux; Android 7.1.2; Pixel XL Build/NZH54D; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.132 MQQBrowser/6.2 TBS/043909 Mobile Safari/537.36 MicroMessenger/6.6.3.1260(0x26060336) NetType/WIFI Language/zh_CN
Cookie: wxuin=3789529722; devicetype=android-23; version=26060532; lang=zh_CN; pass_ticket=/0CNwnlanWByDE+oz3ssxVMY75/FjuAe4bXG/nHvn5C+ZKEMZeXoEupWQe5viX0P; wap_sid2=CPrE/o4OEogBTzMtV2tmLXU2ZHdTV282RXpuQVhWcjA2TEVZSlVUdkF4U0hhRkxpdTV0aEJPOXYycVdsLUYzNk9mc0JXdFlXMDhxUmdGcjZaanRYelE4ZmN0eGltdE9za0RYQUkxbm9iTnZ3UHhsc09zZm1zUFZtbk05WTFvSlc1Vm4zQk5iNUJ3QU1BQUF+fjC1i/7YBTgNQAE=; rewardsn=; wxtokenkey=777
Q-UA2: QV=3&PL=ADR&PR=WX&PP=com.tencent.mm&PPVN=6.6.5&TBSVC=43603&CO=BK&COVC=043909&PB=GE&VE=GA&DE=PHONE&CHID=0&LCID=9422&MO= PixelXL &RL=1440*2392&OS=7.1.2&API=25
Q-GUID: b08a5edb5e2a655000ca6e7e13b788cb
Q-Auth: 31045b957cf33acf31e40be2f3e71c5217597676a9729f1b
X-Requested-With: XMLHttpRequest
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
Accept-Language: zh-CN,en-US;q=0.8
Host: mp.weixin.qq.com
Accept-Encoding: gzip
Content-Length: 570






{"advertisement_num":0,"advertisement_info":[],"appmsgstat":{"show":true,"is_login":true,"liked":false,"read_num":35,"like_num":2,"ret":0,"real_read_num":0},"comment_enabled":1,"reward_head_imgs":[],"only_fans_can_comment":false,"comment_count":0,"is_fans":1,"nick_name":"测试机器人","logo_url":"http:\/\/wx.qlogo.cn\/mmopen\/h29PqzMrB7uqDTzZzGNvhibwdQB8rIC5t4fgXWIFibKlmXEaLNxj2RqZWzfKCfvPRjDziabBibPYz619vmI3ZnUz5XNfZSUoMNyK\/132","friend_comment_enabled":1,"base_resp":{"wxtoken":777}}

#Referer
https://www.cnblogs.com/bonelee/p/7875163.html

本手机得Q-GUID:0be094f58bb6d9b8daa83cab13b788cb
无阅读数时候 Referer 在heard中都是缺失的 



