POST /mp/getappmsgext?f=json&mock=&uin=777&key=777&pass_ticket=x3ODivRebEVGkOmjyRWSXh1%25252BpZPSpxRuEdPDbqmFvnqPHeRkygcr1L34cCAySFPg&wxtoken=777&devicetype=android-23&clientversion=26060532&appmsg_token=960_YAp%252B07ZVIoNgdR9jmSoN7X9H6iJ89Yu7z1K5diRNk9Kap0MGLMIThU5Satg7aODUZTfPaALVhfqjGRa_&x5=1&f=json HTTP/1.1
accept: */*
connection: Keep-Alive
user-agent: Mozilla/5.0 (Linux; Android 7.1.2; Pixel XL Build/NZH54D; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.132 MQQBrowser/6.2 TBS/043909 Mobile Safari/537.36 MicroMessenger/6.6.3.1260(0x26060336) NetType/WIFI Language/zh_CN
Cookie: pgv_info=ssid=s2851055945; ts_last=mp.weixin.qq.com/tp/ad_detail_info; pgv_pvid=4726822604; ts_uid=7594210250; rewardsn=; wxtokenkey=777; wxuin=3789529722; devicetype=android-23; version=26060532; lang=zh_CN; pass_ticket=x3ODivRebEVGkOmjyRWSXh1+pZPSpxRuEdPDbqmFvnqPHeRkygcr1L34cCAySFPg; wap_sid2=CPrE/o4OEnB1enNtek9sMDJRdFJNS2NrOGVudzFrTmIzTTkySmE1Q3BkNFQ2ZGsyWW1NNVFWUHJ5WTlpWmd3ZGlCSHh0NTl0aHYyN3F5YjJRNGppTmNnLTBUcVNNWVV1OVZUVDZ1emgxVk1fS3BLUll1WEFBd0FBMJSl/9gFOA1AAQ==
Q-UA2: QV=3&PL=ADR&PR=WX&PP=com.tencent.mm&PPVN=6.6.5&TBSVC=43603&CO=BK&COVC=043909&PB=GE&VE=GA&DE=PHONE&CHID=0&LCID=9422&MO= PixelXL &RL=1440*2392&OS=7.1.2&API=25
Q-GUID: b08a5edb5e2a655000ca6e7e13b788cb
Q-Auth: 31045b957cf33acf31e40be2f3e71c5217597676a9729f1b
X-Requested-With: XMLHttpRequest
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
Accept-Language: zh-CN,en-US;q=0.8
Host: mp.weixin.qq.com
Accept-Encoding: gzip
Content-Length: 566


{"advertisement_num":0,"advertisement_info":[],"appmsgstat":{"show":true,"is_login":true,"liked":false,"read_num":68,"like_num":1,"ret":0,"real_read_num":0},"reward_head_imgs":[],"base_resp":{"wxtoken":777}}