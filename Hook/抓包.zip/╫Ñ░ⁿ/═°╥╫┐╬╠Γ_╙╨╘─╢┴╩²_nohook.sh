POST /mp/getappmsgext?f=json&mock=&uin=777&key=777&pass_ticket=uvAOWVTf%25252F1LfD2nrBxqtxC3vb3NCO5%25252B%25252BaFvoMq10%25252BEJ1VW6avhCRzwtER3faUw4u&wxtoken=777&devicetype=android-23&clientversion=26060532&appmsg_token=960_nWjhmkoG9xmC84q5PVSwcYIAVfsAGTwY8Y-HQjDRRucFk6cDRWsdaznji5cZ6RH2jcY0yR-DZg0pBcOA&x5=1&f=json HTTP/1.1
Host: mp.weixin.qq.com
Connection: keep-alive
Content-Length: 925
Origin: https://mp.weixin.qq.com
X-Requested-With: XMLHttpRequest
User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; AOSP on HammerHead Build/MOB31Z; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.132 MQQBrowser/6.2 TBS/044106 Mobile Safari/537.36 MicroMessenger/6.6.5.1280(0x26060532) NetType/WIFI Language/zh_CN
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
Accept: */*
Referer: https://mp.weixin.qq.com/s?__biz=MjM5MDA1Njk4MA==&mid=2650363071&idx=3&sn=66e28ab81023594c42b0dc3f019e610e&ascene=1&devicetype=android-23&version=26060532&nettype=WIFI&abtest_cookie=AwABAAoACwAMAAkAPoseAOOLHgBIkh4A8JIeAG%2BTHgCdkx4AuZMeAPKTHgD9kx4AAAA%3D&lang=zh_CN&pass_ticket=uvAOWVTf%2F1LfD2nrBxqtxC3vb3NCO5%2B%2BaFvoMq10%2BEJ1VW6avhCRzwtER3faUw4u&wx_header=1
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,en-US;q=0.8
Cookie: rewardsn=; wxtokenkey=777; wxuin=3789529722; devicetype=android-23; version=26060532; lang=zh_CN; pass_ticket=uvAOWVTf/1LfD2nrBxqtxC3vb3NCO5++aFvoMq10+EJ1VW6avhCRzwtER3faUw4u; wap_sid2=CPrE/o4OEnB1enNtek9sMDJRdFJNS2NrOGVudzFnckhIc19obDIyT1BkZ2Npeks4cGxUWVpNbUQ2bEpYb1c4VThCQ0N4c2FEUTdKRkk0Zk51VjdxcnB0YkZGZC1NU0Q2b0hsR3dUSU9WaTdlakptUjZJX0FBd0FBMKKc/9gFOA1AAQ==
Q-UA2: QV=3&PL=ADR&PR=WX&PP=com.tencent.mm&PPVN=6.6.5&TBSVC=43603&CO=BK&COVC=044106&PB=GE&VE=GA&DE=PHONE&CHID=0&LCID=9422&MO= AOSPonHammerHead &RL=1080*1776&OS=6.0.1&API=23
Q-GUID: 0be094f58bb6d9b8daa83cab13b788cb
Q-Auth: 31045b957cf33acf31e40be2f3e71c5217597676a9729f1b


{"advertisement_num":0,"advertisement_info":[],"appmsgstat":{"show":true,"is_login":true,"liked":false,"read_num":5642,"like_num":24,"ret":0,"real_read_num":0},"comment_enabled":1,"reward_head_imgs":[],"only_fans_can_comment":false,"comment_count":9,"is_fans":0,"nick_name":"测试机器人","logo_url":"http:\/\/wx.qlogo.cn\/mmopen\/CB62DhMPeGdz3iavnXic6Y1ib8AOrlgx6oq7Ig28m5asc7urHiaXl71hncIsfA53mxzeLe9kZKnv9ovGrTibicWpSFjnefosCslTOg\/132","friend_comment_enabled":1,"base_resp":{"wxtoken":777}}



POST /mp/getappmsgext?f=json&mock=&uin=777&key=777&pass_ticket=uvAOWVTf%25252F1LfD2nrBxqtxC3vb3NCO5%25252B%25252BaFvoMq10%25252BEJ1VW6avhCRzwtER3faUw4u&wxtoken=777&devicetype=android-23&clientversion=26060532&appmsg_token=960_fwGJsaVrvqDzEN3JPVSwcYIAVfsAGTwY8Y-HQuXGndN18H7VKhcH6KKGiW5wnS_0mLpKHilP0msBEp2T&x5=1&f=json HTTP/1.1
Host: mp.weixin.qq.com
Connection: keep-alive
Content-Length: 925
Origin: https://mp.weixin.qq.com
X-Requested-With: XMLHttpRequest
User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; AOSP on HammerHead Build/MOB31Z; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.132 MQQBrowser/6.2 TBS/044106 Mobile Safari/537.36 MicroMessenger/6.6.5.1280(0x26060532) NetType/WIFI Language/zh_CN
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
Accept: */*
Referer: https://mp.weixin.qq.com/s?__biz=MjM5MDA1Njk4MA==&mid=2650363071&idx=3&sn=66e28ab81023594c42b0dc3f019e610e&ascene=1&devicetype=android-23&version=26060532&nettype=WIFI&abtest_cookie=AwABAAoACwAMAAkAPoseAOOLHgBIkh4A8JIeAG%2BTHgCdkx4AuZMeAPKTHgD9kx4AAAA%3D&lang=zh_CN&pass_ticket=uvAOWVTf%2F1LfD2nrBxqtxC3vb3NCO5%2B%2BaFvoMq10%2BEJ1VW6avhCRzwtER3faUw4u&wx_header=1
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,en-US;q=0.8
Cookie: rewardsn=; wxtokenkey=777; wxuin=3789529722; devicetype=android-23; version=26060532; lang=zh_CN; pass_ticket=uvAOWVTf/1LfD2nrBxqtxC3vb3NCO5++aFvoMq10+EJ1VW6avhCRzwtER3faUw4u; wap_sid2=CPrE/o4OEnB1enNtek9sMDJRdFJNS2NrOGVudzFuWjBZajBYSjhRX1kyZXNRMGVCdHZqRFhCYmVBUFhqMWhkSGM3d01OQ0ltQzhxdGtwWXk1TDAxMUVUUnUyN0ZhUGpnZlBlel90cV93aEJwTmRWNW5GYkFBd0FBMNCd/9gFOA1AAQ==
Q-UA2: QV=3&PL=ADR&PR=WX&PP=com.tencent.mm&PPVN=6.6.5&TBSVC=43603&CO=BK&COVC=044106&PB=GE&VE=GA&DE=PHONE&CHID=0&LCID=9422&MO= AOSPonHammerHead &RL=1080*1776&OS=6.0.1&API=23
Q-GUID: 0be094f58bb6d9b8daa83cab13b788cb
Q-Auth: 31045b957cf33acf31e40be2f3e71c5217597676a9729f1b
